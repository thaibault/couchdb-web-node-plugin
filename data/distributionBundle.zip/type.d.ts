/// <reference types="pouchdb-core" />
/// <reference types="pouchdb-find" />
/// <reference types="pouchdb-mapreduce" />
/// <reference types="pouchdb-replication" />
/// <reference types="pouchdb-adapter-cordova-sqlite" />
/// <reference types="pouchdb-adapter-fruitdown" />
/// <reference types="pouchdb-adapter-http" />
/// <reference types="pouchdb-adapter-idb" />
/// <reference types="pouchdb-adapter-leveldb" />
/// <reference types="pouchdb-adapter-localstorage" />
/// <reference types="pouchdb-adapter-memory" />
/// <reference types="pouchdb-adapter-websql" />
/// <reference types="node" />
import { ChildProcess } from 'child_process';
import Tools from 'clientnode';
import { AnyFunction, Mapping, PlainObject, Primitive, ProcessCloseReason } from 'clientnode/type';
import { Configuration as BaseConfiguration, PluginHandler as BasePluginHandler, ServicePromises as BaseServicePromises, Services as BaseServices, ServicePromisesState as BaseServicePromisesState, ServicesState as BaseServicesState } from 'web-node/type';
import DatabaseHelper from './databaseHelper';
export declare type Attachments = PouchDB.Core.Attachments;
export declare type FullAttachment = PouchDB.Core.FullAttachment;
export declare type StubAttachment = PouchDB.Core.StubAttachment;
export declare type ChangesMeta = PouchDB.Core.ChangesMeta;
export declare type ChangesResponseChange<Type extends Mapping<unknown> = Mapping<unknown>> = PouchDB.Core.ChangesResponseChange<Type>;
export declare type ChangesStream<Type extends Mapping<unknown> = Mapping<unknown>> = PouchDB.Core.Changes<Type>;
export declare type ChangesStreamOptions = PouchDB.Core.ChangesOptions;
export declare type Connection = PouchDB.Database;
export declare type Connector = PouchDB.Static;
export declare type DatabaseConnectorConfiguration = PouchDB.Configuration.RemoteDatabaseConfiguration;
export declare type DatabaseError = PouchDB.Core.Error;
export declare type DatabaseFetch = PouchDB.Core.Options['fetch'];
export declare type DatabaseResponse = PouchDB.Core.Response;
export declare type DeleteIndexOptions = PouchDB.Find.DeleteIndexOptions;
export declare type Document<Type extends Mapping<unknown> = PlainObject> = PouchDB.Core.Document<Type>;
export declare type ExistingDocument<Type extends Mapping<unknown> = PlainObject> = PouchDB.Core.ExistingDocument<Type>;
export declare type DocumentGetMeta = PouchDB.Core.GetMeta;
export declare type DocumentIDMeta = PouchDB.Core.IdMeta;
export declare type DocumentRevisionIDMeta = PouchDB.Core.RevisionIdMeta;
export declare type Index = PouchDB.Find.Index;
export declare type DatabasePlugin = AnyFunction;
export declare type AllowedRoles = (Array<string> | string | {
    read?: Array<string> | string;
    write?: Array<string> | string;
});
export interface NormalizedAllowedRoles {
    read: Array<string>;
    write: Array<string>;
}
export interface NormalizedAllowedModelRoles extends NormalizedAllowedRoles {
    properties: Mapping<NormalizedAllowedRoles>;
}
export declare type AllowedModelRolesMapping = Mapping<NormalizedAllowedModelRoles>;
export interface Constraint {
    description?: null | string;
    evaluation: string;
}
export declare type Type = string | 'any' | 'boolean' | 'integer' | 'number' | 'string' | 'DateTime';
export declare type TypeSpecification = Array<Type> | Type;
export declare type ConstraintKey = 'arrayConstraintExecution' | 'arrayConstraintExpression' | 'conflictingConstraintExecution' | 'conflictingConstraintExpression' | 'constraintExecution' | 'constraintExpression';
export interface SelectionMapping {
    label: string;
    value: unknown;
}
export interface PropertySpecification {
    allowedRoles?: AllowedRoles | null;
    arrayConstraintExecution?: Constraint | null;
    arrayConstraintExpression?: Constraint | null;
    conflictingConstraintExecution?: Constraint | null;
    conflictingConstraintExpression?: Constraint | null;
    constraintExecution?: Constraint | null;
    constraintExpression?: Constraint | null;
    contentTypeRegularExpressionPattern?: null | string;
    default?: unknown;
    emptyEqualsToNull?: boolean | null;
    index?: boolean | null;
    invertedContentTypeRegularExpressionPattern?: null | string;
    invertedRegularExpressionPattern?: null | string;
    maximum?: null | number;
    maximumAggregatedSize?: null | number;
    maximumLength?: null | number;
    maximumNumber?: null | number;
    maximumSize?: null | number;
    minimum?: null | number;
    minimumAggregatedSize?: null | number;
    minimumLength?: null | number;
    minimumNumber?: null | number;
    minimumSize?: null | number;
    mutable?: boolean | null;
    nullable?: boolean | null;
    onCreateExecution?: null | string;
    onCreateExpression?: null | string;
    oldName?: Array<string> | null | string;
    onUpdateExecution?: null | string;
    onUpdateExpression?: null | string;
    regularExpressionPattern?: null | string;
    selection?: Array<unknown> | Array<SelectionMapping> | Mapping<unknown> | null;
    trim?: boolean | null;
    type?: TypeSpecification | null;
    value?: unknown;
    writable?: boolean | null;
}
export interface FileSpecification extends PropertySpecification {
    fileName?: PropertySpecification;
}
export interface BaseModel {
    _allowedRoles?: AllowedRoles | null;
    _attachments?: Mapping<FileSpecification> | null;
    _constraintExecutions?: Array<Constraint> | Constraint | null;
    _constraintExpressions?: Array<Constraint> | Constraint | null;
    _createExecution?: null | string;
    _createExpression?: null | string;
    _extends?: Array<string> | null | string;
    _maximumAggregatedSize?: null | number;
    _minimumAggregatedSize?: null | number;
    _oldType?: Array<string> | null | string;
    _onUpdateExecution?: null | string;
    _onUpdateExpression?: null | string;
}
export declare type Model = BaseModel & Mapping<PropertySpecification>;
export declare type Models = Mapping<Model>;
export declare const PrimitiveTypes: readonly ["boolean", "DateTime", "integer", "number", "string"];
export declare type UpdateStrategy = '' | 'fillUp' | 'incremental' | 'migrate';
export declare type DocumentContent = Array<DocumentContent> | PlainObject<Primitive> | Primitive;
export declare type DocumentStrategyMeta = {
    _updateStrategy?: UpdateStrategy;
};
export declare type DocumentTypeMeta = {
    '-type': string;
};
export declare type BaseDocument = ChangesMeta & DocumentGetMeta & DocumentIDMeta & DocumentRevisionIDMeta & DocumentStrategyMeta & DocumentTypeMeta;
export declare type FullDocument = BaseDocument & PlainObject;
export declare type PartialFullDocument = Partial<BaseDocument> & PlainObject;
export interface SpecialPropertyNames {
    additional: '_additional';
    allowedRole: '_allowedRoles';
    attachment: '_attachments';
    conflict: '_conflicts';
    deleted: '_deleted';
    deletedConflict: '_deleted_conflict';
    extend: '_extends';
    id: '_id';
    revision: '_rev';
    revisions: '_revisions';
    revisionsInformation: '_revs_info';
    strategy: '_updateStrategy';
    type: keyof DocumentTypeMeta;
    constraint: {
        execution: string;
        expression: string;
    };
    create: {
        execution: string;
        expression: string;
    };
    designDocumentNamePrefix: string;
    localSequence: string;
    maximumAggregatedSize: string;
    minimumAggregatedSize: string;
    oldType: string;
    update: {
        execution: string;
        expression: string;
    };
}
export interface PropertyNameConfiguration {
    reserved: Array<string>;
    special: SpecialPropertyNames;
    typeRegularExpressionPattern: {
        private: string;
        public: string;
    };
    validatedDocumentsCache: string;
}
export interface BaseModelConfiguration {
    dateTimeFormat: 'iso' | 'iso8601' | 'number';
    property: {
        defaultSpecification: PropertySpecification;
        name: PropertyNameConfiguration;
    };
    updateStrategy: UpdateStrategy;
}
export interface ModelConfiguration extends BaseModelConfiguration {
    autoMigrationPath: string;
    entities: Models;
    triggerInitialCompaction: boolean;
    updateConfiguration: boolean;
    updateValidation: boolean;
}
export interface UserContext {
    db: string;
    name?: string;
    roles: Array<string>;
}
export interface DatabaseUserConfiguration {
    names: Array<string>;
    roles: Array<string>;
}
export interface Runner {
    adminUserConfigurationPath: string;
    arguments?: Array<string> | null | string;
    binaryFilePath?: null | string;
    configurationFile?: null | {
        content: string;
        path: string;
    };
    environment?: null | Mapping;
    location: Array<string> | string;
    name: Array<string> | string;
}
export interface SecuritySettings {
    admins: DatabaseUserConfiguration;
    members: DatabaseUserConfiguration;
    _validatedDocuments?: Set<string>;
}
export declare type ConnectorConfiguration = DatabaseConnectorConfiguration & {
    fetch?: (RequestInit & {
        timeout: number;
    }) | null;
};
export declare type Configuration<ConfigurationType = Mapping<unknown>> = BaseConfiguration<{
    couchdb: {
        attachAutoRestarter: boolean;
        backend: {
            configuration: PlainObject;
            prefixes: Array<string>;
        };
        binary: {
            memoryInMegaByte: string;
            nodePath: string;
            runner: Array<Runner>;
        };
        changesStream: ChangesStreamOptions;
        connector: ConnectorConfiguration;
        createGenericFlatIndex: boolean;
        databaseName: string;
        debug: boolean;
        ensureAdminPresence: boolean;
        ensureSecuritySettingsPresence: boolean;
        ensureUserPresence: boolean;
        ignoreNoChangeError: boolean;
        local: boolean;
        maximumRepresentationLength: number;
        maximumRepresentationTryLength: number;
        model: ModelConfiguration;
        path: string;
        security: SecuritySettings;
        skipIDDetermining: boolean;
        url: string;
        user: {
            name: string;
            password: string;
        };
    };
}> & ConfigurationType;
export interface CouchDB {
    changesStream: ChangesStream;
    connection: Connection;
    connector: Connector;
    server: {
        process: ChildProcess;
        reject: (value: ProcessCloseReason) => void;
        resolve: (reason: ProcessCloseReason) => void;
        restart: (state: State) => Promise<void>;
        runner: Runner;
        start: (services: Services, configuration: Configuration) => Promise<void>;
        stop: (services: Services, configuration: Configuration) => Promise<void>;
    };
}
export declare type ServicePromises<Type = Mapping<unknown>> = BaseServicePromises<{
    couchdb: Promise<ProcessCloseReason>;
}> & Type;
export declare type Services<Type = Mapping<unknown>> = BaseServices<{
    couchdb: CouchDB;
}> & Type;
export declare type ServicesState<Type = undefined> = BaseServicesState<Type, Configuration, Services>;
export declare type State<Type = undefined> = BaseServicePromisesState<Type, Configuration, Services, ServicePromises>;
export interface PluginHandler extends BasePluginHandler {
    /**
     * Hook after each data change.
     * @param state - Application state.
     *
     * @returns Promise resolving to nothing.
     */
    couchdbInitializeChangesStream?(state: State<ChangesStream>): Promise<void>;
    /**
     * Hook after each data base restart.
     * @param state - Application state.
     *
     * @returns Promise resolving to nothing.
     */
    restartCouchdb?(state: State): Promise<void>;
}
export interface EmptyEvaluationExceptionData {
    empty: string;
}
export declare type EmptyEvaluationException = Exception<EmptyEvaluationExceptionData>;
export interface EvaluationExceptionData<S = Mapping<unknown>> {
    code: string;
    error: Error;
    scope: S;
}
export interface CompilationExceptionData<S = Mapping<unknown>> extends EvaluationExceptionData<S> {
    compilation: string;
}
export interface RuntimeExceptionData<S = Mapping<unknown>> extends EvaluationExceptionData<S> {
    runtime: string;
}
export declare type EvaluationException<S = Mapping<unknown>> = Exception<EvaluationExceptionData<S>>;
export interface BasicScope {
    attachmentWithPrefixExists: (namePrefix: string) => boolean;
    checkDocument: (newDocument: PartialFullDocument, oldDocument: PartialFullDocument | null, parentNames: Array<string>) => CheckedDocumentResult;
    getFileNameByPrefix: (prefix?: string, attachments?: Attachments) => null | string;
    serialize: (value: unknown) => string;
    id: string;
    revision: string;
    idName: string;
    revisionName: string;
    specialNames: SpecialPropertyNames;
    typeName: string;
    modelConfiguration: BaseModelConfiguration;
    models: Models;
    now: Date;
    nowUTCTimestamp: number;
    securitySettings: Partial<SecuritySettings>;
    userContext: Partial<UserContext>;
}
export interface CommonScope {
    checkPropertyContent: (newValue: unknown, name: string, propertySpecification: PropertySpecification, oldValue: unknown) => CheckedPropertyResult;
    model: Model;
    modelName: string;
    type: string;
    newDocument: Attachments | PartialFullDocument;
    oldDocument: Attachments | null | PartialFullDocument;
    parentNames: Array<string>;
    pathDescription: string;
}
export interface PropertyScope extends CommonScope {
    name: string;
    newValue: unknown;
    oldValue: unknown;
    propertySpecification: PropertySpecification;
}
export interface EvaluationResult<T = unknown, S = BasicScope & CommonScope> {
    code: string;
    result: T;
    scope: S;
}
export declare type Evaluate<R = unknown, P = unknown> = (...parameters: Array<P>) => R;
export interface CheckedResult {
    changedPath: Array<string>;
}
export interface CheckedPropertyResult extends CheckedResult {
    newValue: unknown;
}
export interface CheckedDocumentResult extends CheckedResult {
    newDocument: PartialFullDocument;
}
export declare type Exception<DataType = Mapping<unknown>> = {
    message: string;
    name: string;
} & DataType;
export declare type Migrator = (document: Document, scope: {
    configuration: Configuration;
    databaseHelper: DatabaseHelper;
    tools: typeof Tools;
    idName: string;
    typeName: string;
    migrater: Mapping<Migrator>;
    models: Models;
    modelConfiguration: ModelConfiguration;
    selfFilePath: string;
    services: Services;
}) => Document | null;
export declare type DateRepresentationType = Date | null | number | string;
export declare type User = BaseDocument & {
    password: string;
    roles: Array<string>;
};
export interface Interval {
    end: number;
    start: number;
}
export interface Location {
    latitude: number;
    longitude: number;
}

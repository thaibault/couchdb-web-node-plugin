if(typeof window==='undefined'||window===null)var window=(typeof globalThis==='undefined'||globalThis===null)?{}:globalThis;import { default as __WEBPACK_EXTERNAL_MODULE_express_default__ } from "express";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_dfc8e14f_default__ } from "express-pouchdb";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_bulk_get_js_84833b20_default__ } from "express-pouchdb/lib/routes/bulk-get.js";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_all_docs_js_36951003_default__ } from "express-pouchdb/lib/routes/all-docs.js";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_changes_js_1c9a918c_default__ } from "express-pouchdb/lib/routes/changes.js";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_compact_js_706cd168_default__ } from "express-pouchdb/lib/routes/compact.js";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_revs_diff_js_ba19198f_default__ } from "express-pouchdb/lib/routes/revs-diff.js";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_security_js_50ab4613_default__ } from "express-pouchdb/lib/routes/security.js";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_view_cleanup_js_fee1a5b7_default__ } from "express-pouchdb/lib/routes/view-cleanup.js";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_temp_views_js_ef780b3f_default__ } from "express-pouchdb/lib/routes/temp-views.js";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_find_js_2ecae47a_default__ } from "express-pouchdb/lib/routes/find.js";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_views_js_ff545ad5_default__ } from "express-pouchdb/lib/routes/views.js";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_ddoc_info_js_67f6cba3_default__ } from "express-pouchdb/lib/routes/ddoc-info.js";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_show_js_c9474ce8_default__ } from "express-pouchdb/lib/routes/show.js";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_list_js_02ae9e9b_default__ } from "express-pouchdb/lib/routes/list.js";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_update_js_0ad2a14d_default__ } from "express-pouchdb/lib/routes/update.js";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_attachments_js_5b735a6c_default__ } from "express-pouchdb/lib/routes/attachments.js";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_documents_js_6e87b759_default__ } from "express-pouchdb/lib/routes/documents.js";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_validation_js_cd8e1550_default__ } from "express-pouchdb/lib/validation.js";
import { default as __WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_404_js_9d79e21e_default__ } from "express-pouchdb/lib/routes/404.js";
export const __webpack_esm_ids__ = [3];
export const __webpack_esm_modules__ = {

/***/ 18
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ loadExpress),
  utilities: () => (/* binding */ utilities)
});

;// external "express"

;// external "express-pouchdb"

;// external "express-pouchdb/lib/routes/bulk-get.js"

;// external "express-pouchdb/lib/routes/all-docs.js"

;// external "express-pouchdb/lib/routes/changes.js"

;// external "express-pouchdb/lib/routes/compact.js"

;// external "express-pouchdb/lib/routes/revs-diff.js"

;// external "express-pouchdb/lib/routes/security.js"

;// external "express-pouchdb/lib/routes/view-cleanup.js"

;// external "express-pouchdb/lib/routes/temp-views.js"

;// external "express-pouchdb/lib/routes/find.js"

;// external "express-pouchdb/lib/routes/views.js"

;// external "express-pouchdb/lib/routes/ddoc-info.js"

;// external "express-pouchdb/lib/routes/show.js"

;// external "express-pouchdb/lib/routes/list.js"

;// external "express-pouchdb/lib/routes/update.js"

;// external "express-pouchdb/lib/routes/attachments.js"

;// external "express-pouchdb/lib/routes/documents.js"

;// external "express-pouchdb/lib/validation.js"

;// external "express-pouchdb/lib/routes/404.js"

;// ./loadExpress.ts
// -*- coding: utf-8 -*-
/** @module loadExpress *//* !
    region header
    Copyright Torben Sickert (info["~at~"]torben.website) 16.12.2012

    License
    -------

    This library written by Torben Sickert stands under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/// region imports
// endregion
var utilities={express:__WEBPACK_EXTERNAL_MODULE_express_default__,expressPouchDB:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_dfc8e14f_default__,bulkGet:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_bulk_get_js_84833b20_default__,allDocs:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_all_docs_js_36951003_default__,changes:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_changes_js_1c9a918c_default__,compact:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_compact_js_706cd168_default__,revsDiff:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_revs_diff_js_ba19198f_default__,security:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_security_js_50ab4613_default__,viewCleanup:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_view_cleanup_js_fee1a5b7_default__,tempViews:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_temp_views_js_ef780b3f_default__,find:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_find_js_2ecae47a_default__,views:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_views_js_ff545ad5_default__,ddocInfo:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_ddoc_info_js_67f6cba3_default__,show:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_show_js_c9474ce8_default__,list:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_list_js_02ae9e9b_default__,update:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_update_js_0ad2a14d_default__,attachments:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_attachments_js_5b735a6c_default__,documents:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_documents_js_6e87b759_default__,validation:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_validation_js_cd8e1550_default__,notFoundError:__WEBPACK_EXTERNAL_MODULE_express_pouchdb_lib_routes_404_js_9d79e21e_default__};/* harmony default export */ const loadExpress = (utilities);

/***/ }

};

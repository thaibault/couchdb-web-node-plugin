import { Mapping, ValueOf } from 'clientnode/type';
import { AllowedModelRolesMapping, AllowedRoles, Configuration, Connection, DatabaseConnectorConfiguration, Model, ModelConfiguration, Models, NormalizedAllowedRoles, PropertySpecification, Services, SpecialPropertyNames } from './type';
/**
 * Converts internal declarative database connector configuration object
 * into a database compatible one.
 * @param configuration - Mutable by plugins extended configuration object.
 *
 * @returns Database compatible configuration object.
*/
export declare const getConnectorOptions: (configuration: Configuration) => DatabaseConnectorConfiguration;
/**
 * Determines a representation for given plain object.
 * @param object - Object to represent.
 * @param maximumRepresentationTryLength - Maximum representation string to
 * process.
 * @param maximumRepresentationLength - Maximum length of returned
 * representation.
 *
 * @returns Representation string.
 */
export declare const mayStripRepresentation: (object: unknown, maximumRepresentationTryLength: number, maximumRepresentationLength: number) => string;
/**
 * Updates/creates a design document in database with a validation function
 * set to given code.
 * @param databaseConnection - Database connection to use for document
 * updates.
 * @param documentName - Design document name.
 * @param documentData - Design document data.
 * @param description - Used to produce semantic logging messages.
 * @param log - Enables logging.
 * @param idName - Property name for ids.
 * @param revisionName - Property name for revisions.
 * @param designDocumentNamePrefix - Document name prefix indicating deign
 * documents.
 *
 * @returns Promise which will be resolved after given document has updated
 * successfully.
 */
export declare const ensureValidationDocumentPresence: (databaseConnection: Connection, documentName: string, documentData: Mapping, description: string, log?: boolean, idName?: SpecialPropertyNames['id'], revisionName?: SpecialPropertyNames['revision'], designDocumentNamePrefix?: string) => Promise<void>;
/**
 * Initializes a database connection instance.
 * @param services - An object with stored service instances.
 * @param configuration - Mutable by plugins extended configuration object.
 *
 * @returns Given and extended object of services.
 */
export declare const initializeConnection: (services: Services, configuration: Configuration) => Promise<Services>;
/**
 * Determines a mapping of all models to roles who are allowed to edit
 * corresponding model instances.
 * @param modelConfiguration - Model specification object.
 *
 * @returns The mapping object.
 */
export declare const determineAllowedModelRolesMapping: (modelConfiguration: ModelConfiguration) => AllowedModelRolesMapping;
/**
 * Determines whether given value of a model is a property specification.
 * @param value - Value to analyze.
 *
 * @returns Boolean indicating the case.
 */
export declare const isPropertySpecification: (value: ValueOf<Model>) => value is PropertySpecification<unknown, object>;
/**
 * Determines all property names which are indexable in a generic manner.
 * @param modelConfiguration - Model specification object.
 * @param model - Model to determine property names from.
 *
 * @returns The mapping object.
 */
export declare const determineGenericIndexablePropertyNames: (modelConfiguration: ModelConfiguration, model: Model) => Array<string>;
/**
 * Extend given model with all specified one.
 * @param modelName - Name of model to extend.
 * @param models - Pool of models to extend from.
 * @param extendPropertyName - Property name which indicates model
 * inheritance.
 *
 * @returns Given model in extended version.
 */
export declare const extendModel: (modelName: string, models: Mapping<Partial<Model>>, extendPropertyName?: SpecialPropertyNames['extend']) => Partial<Model>;
/**
 * Extend default specification with specific one.
 * @param modelConfiguration - Model specification object.
 *
 * @returns Models with extended specific specifications.
 */
export declare const extendModels: (modelConfiguration: ModelConfiguration) => Models;
/**
 * Convert given roles to its normalized representation.
 * @param roles - Unstructured roles description.
 *
 * @returns Normalized roles representation.
 */
export declare const normalizeAllowedRoles: (roles: AllowedRoles) => NormalizedAllowedRoles;

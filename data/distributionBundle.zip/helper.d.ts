import { Mapping } from 'clientnode/type';
import { AllowedModelRolesMapping, AllowedRoles, Configuration, Connection, DatabaseConnectorConfiguration, Model, ModelConfiguration, Models, NormalizedAllowedRoles, Services, SpecialPropertyNames, State } from './type';
/**
 * A dumm plugin interface with all available hooks.
 */
export declare class Helper {
    /**
     * Converts internal declarative database connector configuration object
     * into a database compatible one.
     * @param configuration - Mutable by plugins extended configuration object.
     *
     * @returns Database compatible configuration object.
    */
    static getConnectorOptions(this: void, configuration: Configuration): DatabaseConnectorConfiguration;
    /**
     * Determines a representation for given plain object.
     * @param object - Object to represent.
     * @param maximumRepresentationTryLength - Maximum representation string to
     * process.
     * @param maximumRepresentationLength - Maximum length of returned
     * representation.
     *
     * @returns Representation string.
     */
    static mayStripRepresentation(this: void, object: unknown, maximumRepresentationTryLength: number, maximumRepresentationLength: number): string;
    /**
     * Updates/creates a design document in database with a validation function
     * set to given code.
     * @param databaseConnection - Database connection to use for document
     * updates.
     * @param documentName - Design document name.
     * @param documentData - Design document data.
     * @param description - Used to produce semantic logging messages.
     * @param log - Enables logging.
     * @param idName - Property name for ids.
     * @param designDocumentNamePrefix - Document name prefix indicating deign
     * documents.
     *
     * @returns Promise which will be resolved after given document has updated
     * successfully.
     */
    static ensureValidationDocumentPresence(this: void, databaseConnection: Connection, documentName: string, documentData: Mapping, description: string, log?: boolean, idName?: SpecialPropertyNames['id'], designDocumentNamePrefix?: string): Promise<void>;
    /**
     * Initializes a database connection instance.
     * @param services - An object with stored service instances.
     * @param configuration - Mutable by plugins extended configuration object.
     *
     * @returns Given and extended object of services.
     */
    static initializeConnection(this: void, services: Services, configuration: Configuration): Promise<Services>;
    /**
     * Starts server process.
     * @param services - An object with stored service instances.
     * @param configuration - Mutable by plugins extended configuration object.
     *
     * @returns A promise representing the server process wrapped in a promise
     * which resolves after server is reachable.
     */
    static startServer(this: void, services: Services, configuration: Configuration): Promise<void>;
    /**
     * Stops open database connection if exist, stops server process, restarts
     * server process and re-initializes server connection.
     * @param state - Application state.
     *
     * @returns Given object of services wrapped in a promise resolving after
     * after finish.
     */
    static restartServer(this: void, state: State): Promise<void>;
    /**
     * Stops open database connection if exists and stops server process.
     * @param services - An object with stored service instances.
     * @param services.couchdb - Couchdb service instance.
     * @param configuration - Mutable by plugins extended configuration object.
     * @param configuration.couchdb - Mutable by plugins extended configuration
     * object.
     *
     * @returns Given object of services wrapped in a promise resolving after
     * after finish.
     */
    static stopServer(this: void, { couchdb }: Services, { couchdb: configuration }: Configuration): Promise<void>;
    /**
     * Determines a mapping of all models to roles who are allowed to edit
     * corresponding model instances.
     * @param modelConfiguration - Model specification object.
     *
     * @returns The mapping object.
     */
    static determineAllowedModelRolesMapping(this: void, modelConfiguration: ModelConfiguration): AllowedModelRolesMapping;
    /**
     * Determines all property names which are indexable in a generic manner.
     * @param modelConfiguration - Model specification object.
     * @param model - Model to determine property names from.
     *
     * @returns The mapping object.
     */
    static determineGenericIndexablePropertyNames(this: void, modelConfiguration: ModelConfiguration, model: Model): Array<string>;
    /**
     * Extend given model with all specified one.
     * @param modelName - Name of model to extend.
     * @param models - Pool of models to extend from.
     * @param extendPropertyName - Property name which indicates model
     * inheritance.
     *
     * @returns Given model in extended version.
     */
    static extendModel(this: void, modelName: string, models: Models, extendPropertyName?: string): Model;
    /**
     * Extend default specification with specific one.
     * @param modelConfiguration - Model specification object.
     *
     * @returns Models with extended specific specifications.
     */
    static extendModels(this: void, modelConfiguration: ModelConfiguration): Models;
    /**
     * Convert given roles to its normalized representation.
     * @param roles - Unstructured roles description.
     *
     * @returns Normalized roles representation.
     */
    static normalizeAllowedRoles(this: void, roles: AllowedRoles): NormalizedAllowedRoles;
}
export default Helper;

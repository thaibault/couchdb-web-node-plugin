if(typeof window==='undefined'||window===null)var window=(typeof globalThis==='undefined'||globalThis===null)?{}:globalThis;// -*- coding: utf-8 -*-
/** @module type *//* !
    region header
    Copyright Torben Sickert (info["~at~"]torben.website) 16.12.2012

    License
    -------

    This library written by Torben Sickert stands under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/// region imports
// endregion
// region exports
/// region database implementation
/// endregion
/// region model
// Represents a properties read and write roles.
/*
    Recursive mapping from model and properties to their allowed read and write
    roles.
*//*
    Maps an artifact (usually type or property) to corresponding operations
    mapped to their allowed roles.
*/var PrimitiveTypes=["boolean","DateTime","integer","number","string"];// | 'any' | PrimitiveType
/// endregion
/// region web-node api
//// region configuration
//// endregion
/// endregion
/// region evaluation
//// region scopes
//// endregion
/// endregion
/// region checker results
/// endregion
/// region pre-defined models
/*
    Start and end time can be represented as number (of seconds) or an iso
    based datetime string.
*//// endregion
// endregion
export { PrimitiveTypes };

import { Mapping } from 'clientnode';
import { AllowedModelRolesMapping, Attachment, BaseModelConfiguration, Document, Models, PartialFullDocument, SecuritySettings, UserContext } from './type';
/**
 * WebNode plugin interface with all provided hooks.
 */
/**
 * Authorizes given document update against given mapping of allowed roles for
 * writing into corresponding model instances.
 * @param newDocument - Updated document.
 * @param oldDocument - If an existing document should be updated its given
 * here.
 * @param userContext - Contains meta information about currently acting user.
 * @param _securitySettings - Database security settings.
 * @param allowedModelRolesMapping - Allowed roles for given models.
 * @param idPropertyName - Property name indicating the id field name.
 * @param typePropertyName - Property name indicating to which model a document
 * belongs to.
 * @param designDocumentNamePrefix - Document name prefix indicating a design
 * document.
 * @param read - Indicates whether a read or write of given document should be
 * authorized or not.
 * @returns Throws an exception if authorisation is not accepted and "true"
 * otherwise.
 */
export declare const authorize: (newDocument: Partial<Document>, oldDocument?: null | Partial<Document>, userContext?: Partial<UserContext>, _securitySettings?: Partial<SecuritySettings>, allowedModelRolesMapping?: AllowedModelRolesMapping, idPropertyName?: string, typePropertyName?: string, designDocumentNamePrefix?: string, read?: boolean) => true;
/**
 * Represents a design document validation function for given model
 * specification.
 * @param newDocument - Updated document.
 * @param oldDocument - If an existing document should be updated its given
 * here.
 * @param userContext - Contains meta information about currently acting user.
 * @param securitySettings - Database security settings.
 * @param modelConfiguration - Model configuration object.
 * @param models - Models specification object.
 * @param checkPublicModelType - Indicates whether to public model types only.
 * @param toJSON - JSON stringifier.
 * @returns Modified given new document.
 */
export declare const validateDocumentUpdate: <ObjectType extends object = object, AttachmentType extends Attachment = Attachment, AdditionalSpecifications extends object = Mapping<unknown>, AdditionalPropertiesType = unknown>(newDocument: PartialFullDocument<ObjectType, AdditionalPropertiesType>, oldDocument: (null | PartialFullDocument<ObjectType, AdditionalPropertiesType>), userContext: Partial<UserContext>, securitySettings: Partial<SecuritySettings>, modelConfiguration: BaseModelConfiguration<ObjectType, AdditionalSpecifications>, models?: Models<ObjectType, AttachmentType, AdditionalSpecifications, AdditionalPropertiesType>, checkPublicModelType?: boolean, toJSON?: (value: unknown) => string) => PartialFullDocument<ObjectType, AdditionalPropertiesType>;
export declare const databaseHelper: any;
export default databaseHelper;

import { PluginAPI } from 'web-node';
import { Plugin, PluginHandler } from 'web-node/type';
import { ChangesStream, Configuration, Service, ServicePromises, Services } from './type';
/**
 * Launches an application server und triggers all some pluginable hooks on
 * an event.
 * @property static:additionalChangesStreamOptions - Can provide additional
 * (non static) changes stream options.
 * @property static:changesStream - Stream which triggers database events.
 * @property static:skipIDDetermining - Indicates whether id's should be
 * determined if "bulkDocs" had skipped a real change due to ignore a
 * "NoChange" error.
 * @property static:toggleIDDetermining - Token to give a "bulkDocs" method
 * call to indicate id determination skip or not (depends on the static
 * "skipIDDetermining" configuration).
 */
export declare class Database implements PluginHandler {
    static additionalChangesStreamOptions: object;
    static changesStream: ChangesStream;
    static skipIDDetermining: boolean;
    static toggleIDDetermining: symbol;
    /**
     * Start database's child process and return a Promise which observes this
     * service.
     * @param servicePromises - An object with stored service promise
     * instances.
     * @param services - An object with stored service instances.
     * @param configuration - Mutable by plugins extended configuration object.
     *
     * @returns A promise which correspond to the plugin specific continues
     * service.
     */
    static loadService(servicePromises: Omit<ServicePromises, 'couchdb'>, services: Services, configuration: Configuration): Promise<Service>;
    /**
     * Add database event listener to auto restart database server on
     * unexpected server issues.
     * @param servicePromises - An object with stored service promise
     * instances.
     * @param services - An object with stored service instances.
     * @param configuration - Mutable by plugins extended configuration object.
     * @param plugins - Topological sorted list of loaded plugins.
     * @param pluginAPI - Plugin api reference.
     *
     * @returns A promise which wraps plugin promises to represent plugin
     * continues services.
     */
    static postLoadService(servicePromises: ServicePromises, services: Services, configuration: Configuration, plugins: Array<Plugin>, pluginAPI: typeof PluginAPI): ServicePromises;
    /**
     * Appends an application server to the web node services.
     * @param services - An object with stored service instances.
     * @param configuration - Mutable by plugins extended configuration object.
     *
     * @returns Given and extended object of services wrapped in a promise
     * resolving after pre-loading has finished.
     */
    static preLoadService(services: Services, configuration: Configuration): Promise<Services>;
    /**
     * Triggered when application will be closed soon.
     * @param services - An object with stored service instances.
     * @param configuration - Mutable by plugins extended configuration object.
     *
     * @returns Given object of services wrapped in a promise resolving after
     * finish.
     */
    static shouldExit(services: Services, configuration: Configuration): Promise<Services>;
}
export default Database;

import { PluginHandler, PluginPromises } from 'web-node/type';
import { ServicesState, State } from './type';
/**
 * Launches an application server und triggers all some pluginable hooks on
 * an event.
 * @property static:toggleLatestRevisionDetermining - Token to provide to
 * "bulkDocs" method call to indicate id determination skip or not (depends on
 * "skipLatestRevisionDetermining" configuration).
 */
export declare class Database implements PluginHandler {
    static toggleLatestRevisionDetermining: symbol;
    /**
     * Appends an application server to the web node services.
     * @param state - Application state.
     * @param state.configuration - Applications configuration.
     * @param state.configuration.couchdb - Plugins configuration.
     * @param state.services - Applications services.
     *
     * @returns Promise resolving to nothing.
     */
    static preLoadService({ configuration: { couchdb: configuration }, services }: ServicesState): Promise<void>;
    /**
     * Start database's child process and return a Promise which observes this
     * service.
     * @param state - Application state.
     * @param state.configuration - Applications configuration.
     * @param state.services - Applications services.
     *
     * @returns A mapping to promises which correspond to the plugin specific
     * continues services.
     */
    static loadService({ configuration, services }: State): Promise<PluginPromises>;
    /**
     * Add database event listener to auto restart database server on
     * unexpected server issues.
     * @param state - Application state.
     *
     * @returns Promise resolving to nothing.
     */
    static postLoadService(state: State): Promise<void>;
    /**
     * Triggered when application will be closed soon.
     * @param state - Application state.
     * @param state.configuration - Applications configuration.
     * @param state.services - Applications services.
     *
     * @returns Promise resolving to nothing.
     */
    static shouldExit({ configuration, services }: State): Promise<void>;
}
export default Database;

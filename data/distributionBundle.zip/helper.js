if(typeof window==='undefined'||window===null)var window=(typeof globalThis==='undefined'||globalThis===null)?{}:globalThis;import * as __WEBPACK_EXTERNAL_MODULE_clientnode__ from "clientnode";
import { lastValueFrom as __WEBPACK_EXTERNAL_MODULE_rxjs_lastValueFrom__, map as __WEBPACK_EXTERNAL_MODULE_rxjs_map__, retry as __WEBPACK_EXTERNAL_MODULE_rxjs_retry__, timer as __WEBPACK_EXTERNAL_MODULE_rxjs_timer__ } from "rxjs";
import { fromFetch as __WEBPACK_EXTERNAL_MODULE_rxjs_fetch_acb1bba5_fromFetch__ } from "rxjs/fetch";
/******/ var __webpack_modules__ = ([
/* 0 */
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const x = (y) => {
	const x = {}; __webpack_require__.d(x, y); return x
} 
const y = (x) => (() => (x))
module.exports = x({ ["Logger"]: () => (__WEBPACK_EXTERNAL_MODULE_clientnode__.Logger), ["copy"]: () => (__WEBPACK_EXTERNAL_MODULE_clientnode__.copy), ["extend"]: () => (__WEBPACK_EXTERNAL_MODULE_clientnode__.extend), ["format"]: () => (__WEBPACK_EXTERNAL_MODULE_clientnode__.format), ["isObject"]: () => (__WEBPACK_EXTERNAL_MODULE_clientnode__.isObject), ["represent"]: () => (__WEBPACK_EXTERNAL_MODULE_clientnode__.represent), ["timeout"]: () => (__WEBPACK_EXTERNAL_MODULE_clientnode__.timeout) });

/***/ }),
/* 1 */,
/* 2 */
/***/ ((module) => {

module.exports = {"rE":"2.0.854"};

/***/ })
/******/ ]);
/************************************************************************/
/******/ // The module cache
/******/ const __webpack_module_cache__ = {};
/******/ 
/******/ // The require function
/******/ function __webpack_require__(moduleId) {
/******/ 	// Check if module is in cache
/******/ 	const cachedModule = __webpack_module_cache__[moduleId];
/******/ 	if (cachedModule !== undefined) {
/******/ 		return cachedModule.exports;
/******/ 	}
/******/ 	// Create a new module (and put it into the cache)
/******/ 	const module = __webpack_module_cache__[moduleId] = {
/******/ 		// no module.id needed
/******/ 		// no module.loaded needed
/******/ 		exports: {}
/******/ 	};
/******/ 
/******/ 	// Execute the module function
/******/ 	__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 
/******/ 	// Return the exports of the module
/******/ 	return module.exports;
/******/ }
/******/ 
/************************************************************************/
/******/ /* webpack/runtime/define property getters */
/******/ // define getter/value functions for harmony exports
/******/ __webpack_require__.d = (exports, definition) => {
/******/ 	for(var key in definition) {
/******/ 		if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 			Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 		}
/******/ 	}
/******/ };
/******/ 
/******/ /* webpack/runtime/hasOwnProperty shorthand */
/******/ __webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop));
/******/ 
/************************************************************************/

// EXTERNAL MODULE: external "clientnode"
var external_clientnode_ = __webpack_require__(0);
;// external "rxjs"

;// external "rxjs/fetch"

// EXTERNAL MODULE: ./package.json
var package_0 = __webpack_require__(2);
;// ./helper.ts
// -*- coding: utf-8 -*-
/** @module helper *//* !
    region header
    Copyright Torben Sickert (info["~at~"]torben.website) 16.12.2012

    License
    -------

    This library written by Torben Sickert stands under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/// region imports
function ownKeys(e,r){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var o=Object.getOwnPropertySymbols(e);r&&(o=o.filter(function(r){return Object.getOwnPropertyDescriptor(e,r).enumerable})),t.push.apply(t,o)}return t}function _objectSpread(e){for(var r=1;r<arguments.length;r++){var t=null!=arguments[r]?arguments[r]:{};r%2?ownKeys(Object(t),!0).forEach(function(r){_defineProperty(e,r,t[r])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):ownKeys(Object(t)).forEach(function(r){Object.defineProperty(e,r,Object.getOwnPropertyDescriptor(t,r))})}return e}function _slicedToArray(r,e){return _arrayWithHoles(r)||_iterableToArrayLimit(r,e)||_unsupportedIterableToArray(r,e)||_nonIterableRest()}function _nonIterableRest(){throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}function _iterableToArrayLimit(r,l){var t=null==r?null:"undefined"!=typeof Symbol&&r[Symbol.iterator]||r["@@iterator"];if(null!=t){var e,n,i,u,a=[],f=!0,o=!1;try{if(i=(t=t.call(r)).next,0===l){if(Object(t)!==t)return;f=!1}else for(;!(f=(e=i.call(t)).done)&&(a.push(e.value),a.length!==l);f=!0);}catch(r){o=!0,n=r}finally{try{if(!f&&null!=t.return&&(u=t.return(),Object(u)!==u))return}finally{if(o)throw n}}return a}}function _arrayWithHoles(r){if(Array.isArray(r))return r}function _defineProperty(e,r,t){return(r=_toPropertyKey(r))in e?Object.defineProperty(e,r,{value:t,enumerable:!0,configurable:!0,writable:!0}):e[r]=t,e}function _toPropertyKey(t){var i=_toPrimitive(t,"string");return"symbol"==_typeof(i)?i:i+""}function _toPrimitive(t,r){if("object"!=_typeof(t)||!t)return t;var e=t[Symbol.toPrimitive];if(void 0!==e){var i=e.call(t,r||"default");if("object"!=_typeof(i))return i;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===r?String:Number)(t)}function _regenerator(){/*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */var e,t,r="function"==typeof Symbol?Symbol:{},n=r.iterator||"@@iterator",o=r.toStringTag||"@@toStringTag";function i(r,n,o,i){var c=n&&n.prototype instanceof Generator?n:Generator,u=Object.create(c.prototype);return _regeneratorDefine2(u,"_invoke",function(r,n,o){var i,c,u,f=0,p=o||[],y=!1,G={p:0,n:0,v:e,a:d,f:d.bind(e,4),d:function d(t,r){return i=t,c=0,u=e,G.n=r,a}};function d(r,n){for(c=r,u=n,t=0;!y&&f&&!o&&t<p.length;t++){var o,i=p[t],d=G.p,l=i[2];r>3?(o=l===n)&&(u=i[(c=i[4])?5:(c=3,3)],i[4]=i[5]=e):i[0]<=d&&((o=r<2&&d<i[1])?(c=0,G.v=n,G.n=i[1]):d<l&&(o=r<3||i[0]>n||n>l)&&(i[4]=r,i[5]=n,G.n=l,c=0))}if(o||r>1)return a;throw y=!0,n}return function(o,p,l){if(f>1)throw TypeError("Generator is already running");for(y&&1===p&&d(p,l),c=p,u=l;(t=c<2?e:u)||!y;){i||(c?c<3?(c>1&&(G.n=-1),d(c,u)):G.n=u:G.v=u);try{if(f=2,i){if(c||(o="next"),t=i[o]){if(!(t=t.call(i,u)))throw TypeError("iterator result is not an object");if(!t.done)return t;u=t.value,c<2&&(c=0)}else 1===c&&(t=i.return)&&t.call(i),c<2&&(u=TypeError("The iterator does not provide a '"+o+"' method"),c=1);i=e}else if((t=(y=G.n<0)?u:r.call(n,G))!==a)break}catch(t){i=e,c=1,u=t}finally{f=1}}return{value:t,done:y}}}(r,o,i),!0),u}var a={};function Generator(){}function GeneratorFunction(){}function GeneratorFunctionPrototype(){}t=Object.getPrototypeOf;var c=[][n]?t(t([][n]())):(_regeneratorDefine2(t={},n,function(){return this}),t),u=GeneratorFunctionPrototype.prototype=Generator.prototype=Object.create(c);function f(e){return Object.setPrototypeOf?Object.setPrototypeOf(e,GeneratorFunctionPrototype):(e.__proto__=GeneratorFunctionPrototype,_regeneratorDefine2(e,o,"GeneratorFunction")),e.prototype=Object.create(u),e}return GeneratorFunction.prototype=GeneratorFunctionPrototype,_regeneratorDefine2(u,"constructor",GeneratorFunctionPrototype),_regeneratorDefine2(GeneratorFunctionPrototype,"constructor",GeneratorFunction),GeneratorFunction.displayName="GeneratorFunction",_regeneratorDefine2(GeneratorFunctionPrototype,o,"GeneratorFunction"),_regeneratorDefine2(u),_regeneratorDefine2(u,o,"Generator"),_regeneratorDefine2(u,n,function(){return this}),_regeneratorDefine2(u,"toString",function(){return"[object Generator]"}),(_regenerator=function _regenerator(){return{w:i,m:f}})()}function _regeneratorDefine2(e,r,n,t){var i=Object.defineProperty;try{i({},"",{})}catch(e){i=0}_regeneratorDefine2=function _regeneratorDefine(e,r,n,t){function o(r,n){_regeneratorDefine2(e,r,function(e){return this._invoke(r,n,e)})}r?i?i(e,r,{value:n,enumerable:!t,configurable:!t,writable:!t}):e[r]=n:(o("next",0),o("throw",1),o("return",2))},_regeneratorDefine2(e,r,n,t)}function _typeof(o){"@babel/helpers - typeof";return _typeof="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(o){return typeof o}:function(o){return o&&"function"==typeof Symbol&&o.constructor===Symbol&&o!==Symbol.prototype?"symbol":typeof o},_typeof(o)}function _createForOfIteratorHelper(r,e){var t="undefined"!=typeof Symbol&&r[Symbol.iterator]||r["@@iterator"];if(!t){if(Array.isArray(r)||(t=_unsupportedIterableToArray(r))||e&&r&&"number"==typeof r.length){t&&(r=t);var _n=0,F=function F(){};return{s:F,n:function n(){return _n>=r.length?{done:!0}:{done:!1,value:r[_n++]}},e:function e(r){throw r},f:F}}throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}var o,a=!0,u=!1;return{s:function s(){t=t.call(r)},n:function n(){var r=t.next();return a=r.done,r},e:function e(r){u=!0,o=r},f:function f(){try{a||null==t.return||t.return()}finally{if(u)throw o}}}}function _toConsumableArray(r){return _arrayWithoutHoles(r)||_iterableToArray(r)||_unsupportedIterableToArray(r)||_nonIterableSpread()}function _nonIterableSpread(){throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}function _unsupportedIterableToArray(r,a){if(r){if("string"==typeof r)return _arrayLikeToArray(r,a);var t={}.toString.call(r).slice(8,-1);return"Object"===t&&r.constructor&&(t=r.constructor.name),"Map"===t||"Set"===t?Array.from(r):"Arguments"===t||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)?_arrayLikeToArray(r,a):void 0}}function _iterableToArray(r){if("undefined"!=typeof Symbol&&null!=r[Symbol.iterator]||null!=r["@@iterator"])return Array.from(r)}function _arrayWithoutHoles(r){if(Array.isArray(r))return _arrayLikeToArray(r)}function _arrayLikeToArray(r,a){(null==a||a>r.length)&&(a=r.length);for(var e=0,n=Array(a);e<a;e++)n[e]=r[e];return n}function asyncGeneratorStep(n,t,e,r,o,a,c){try{var i=n[a](c),u=i.value}catch(n){return void e(n)}i.done?t(u):Promise.resolve(u).then(r,o)}function _asyncToGenerator(n){return function(){var t=this,e=arguments;return new Promise(function(r,o){var a=n.apply(t,e);function _next(n){asyncGeneratorStep(a,r,o,_next,_throw,"next",n)}function _throw(n){asyncGeneratorStep(a,r,o,_next,_throw,"throw",n)}_next(void 0)})}};// endregion
/*
    Token to provide to "bulkDocs" method call to indicate id determination
    skip or not (depends on "skipLatestRevisionDetermining" configuration).
*/var TOGGLE_LATEST_REVISION_DETERMINING=Symbol("toggleLatestRevisionDetermining");var log=new external_clientnode_.Logger({name:"web-node.couchdb"});/**
 * Determines plugin to hook into any write operations.
 * @param configuration - This's plugin configuration object.
 * @returns A pouchdb plugin in object style.
 */var getPouchDBPlugin=function getPouchDBPlugin(configuration){var _configuration$model$=configuration.model.property.name.special,idName=_configuration$model$.id,revisionName=_configuration$model$.revision,attachmentsPropertyName=_configuration$model$.attachment,deletedName=_configuration$model$.deleted;return{installCouchDBWebNodePlugin:function installCouchDBWebNodePlugin(description){var _this=this;if(this.bulkDocs){var nativeBulkDocs=this.bulkDocs.bind(this);this.bulkDocs=/*#__PURE__*/_asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee(firstParameter){var _len,parameters,_key,toggleLatestRevisionDetermining,skipLatestRevisionDetermining,data,chunkSize,results,_index,chunk,result,conflictingIndexes,conflicts,index,_iterator,_step,item,retriedResults,_iterator2,_step2,retriedResult,_args=arguments,_t,_t2,_t3;return _regenerator().w(function(_context){while(1)switch(_context.p=_context.n){case 0:log.debug("BulkDocs called from:",description);// Normalize parameter to an array of documents.
if((0,external_clientnode_.isObject)(firstParameter)&&Object.keys(firstParameter).length===1&&"docs"in firstParameter&&Array.isArray(firstParameter.docs))firstParameter=firstParameter.docs;for(_len=_args.length,parameters=new Array(_len>1?_len-1:0),_key=1;_key<_len;_key++){parameters[_key-1]=_args[_key]}toggleLatestRevisionDetermining=parameters.length>0&&parameters[parameters.length-1]===TOGGLE_LATEST_REVISION_DETERMINING;skipLatestRevisionDetermining=toggleLatestRevisionDetermining?!configuration.skipLatestRevisionDetermining:configuration.skipLatestRevisionDetermining;if(toggleLatestRevisionDetermining)parameters.pop();data=!Array.isArray(firstParameter)&&(0,external_clientnode_.isObject)(firstParameter)&&idName in firstParameter?[firstParameter]:firstParameter;chunkSize=configuration.maximumNumberOfEntitiesInBulkOperation;results=[];_index=0;case 1:if(!(_index<data.length)){_context.n=4;break}chunk=data.slice(_index,_index+chunkSize);_context.n=2;return nativeBulkDocs.call.apply(nativeBulkDocs,[_this,chunk].concat(_toConsumableArray(parameters)));case 2:result=_context.v;results=results.concat(result);case 3:_index+=chunkSize;_context.n=1;break;case 4:conflictingIndexes=[];conflicts=[];index=0;_iterator=_createForOfIteratorHelper(results);_context.p=5;_iterator.s();case 6:if((_step=_iterator.n()).done){_context.n=13;break}item=_step.value;if(!(_typeof(data[index])==="object")){_context.n=11;break}if(!(revisionName in data[index]&&item.name==="conflict"&&["0-latest","0-upsert"].includes(data[index][revisionName]))){_context.n=7;break}conflicts.push(data[index]);conflictingIndexes.push(index);_context.n=11;break;case 7:if(!(idName in data[index]&&configuration.ignoreNoChangeError&&"name"in item&&item.name==="forbidden"&&"message"in item&&item.message.startsWith("NoChange:"))){_context.n=11;break}results[index]={id:data[index][idName],ok:true};if(skipLatestRevisionDetermining){_context.n=11;break}if(!(revisionName in data[index]&&!["0-latest","0-upsert"].includes(data[index][revisionName]))){_context.n=8;break}_t=data[index][revisionName];_context.n=10;break;case 8:_context.n=9;return _this.get(results[index].id);case 9:_t2=revisionName;_t=_context.v[_t2];case 10:results[index].rev=_t;case 11:index+=1;case 12:_context.n=6;break;case 13:_context.n=15;break;case 14:_context.p=14;_t3=_context.v;_iterator.e(_t3);case 15:_context.p=15;_iterator.f();return _context.f(15);case 16:if(!conflicts.length){_context.n=18;break}data=conflicts;if(toggleLatestRevisionDetermining)parameters.push(TOGGLE_LATEST_REVISION_DETERMINING);_context.n=17;return _this.bulkDocs.apply(_this,[data].concat(_toConsumableArray(parameters)));case 17:retriedResults=_context.v;_iterator2=_createForOfIteratorHelper(retriedResults);try{for(_iterator2.s();!(_step2=_iterator2.n()).done;){retriedResult=_step2.value;results[conflictingIndexes.shift()]=retriedResult}}catch(err){_iterator2.e(err)}finally{_iterator2.f()}case 18:return _context.a(2,results)}},_callee,null,[[5,14,15,16]])}))}this.post=this.put=/*#__PURE__*/_asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee2(document,options){var result;return _regenerator().w(function(_context2){while(1)switch(_context2.n){case 0:_context2.n=1;return _this.bulkDocs([document],options);case 1:result=_context2.v[0];if(!(result!==null&&result!==void 0&&result.name)){_context2.n=2;break}throw result;case 2:return _context2.a(2,result)}},_callee2)}));this.remove=/*#__PURE__*/_asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee3(id,revision){return _regenerator().w(function(_context3){while(1)switch(_context3.n){case 0:return _context3.a(2,_this.put(_defineProperty(_defineProperty(_defineProperty({},idName,id),revisionName,revision),deletedName,true)))}},_callee3)}));if(this.putAttachment)this.putAttachment=/*#__PURE__*/_asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee4(id,attachmentName,revisionOrAttachment,attachmentOrType,type){var _ref5,_type;var attachment,revision;return _regenerator().w(function(_context4){while(1)switch(_context4.n){case 0:if(typeof revisionOrAttachment==="string"){attachment=attachmentOrType;revision=revisionOrAttachment}else{attachment=revisionOrAttachment;revision="0-latest"}return _context4.a(2,_this.put(_defineProperty(_defineProperty(_defineProperty({},idName,id),revisionName,revision),attachmentsPropertyName,_defineProperty({},attachmentName,{/*
                                NOTE: We only need to set a content type to
                                avoid getting a warning.
                            */// eslint-disable-next-line camelcase
content_type:(_ref5=(_type=attachment.type)!==null&&_type!==void 0?_type:type)!==null&&_ref5!==void 0?_ref5:"application/octet-stream",data:attachment}))))}},_callee4)}));if(this.removeAttachment)this.removeAttachment=/*#__PURE__*/_asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee5(id,attachmentName,revision){return _regenerator().w(function(_context5){while(1)switch(_context5.n){case 0:return _context5.a(2,_this.put(_defineProperty(_defineProperty(_defineProperty({},idName,id),revisionName,revision),attachmentsPropertyName,_defineProperty({},attachmentName,{/*
                                NOTE: We only need to set a content type to
                                avoid getting a warning.
                            */// eslint-disable-next-line camelcase
content_type:"application/octet-stream",data:null}))))}},_callee5)}))}}};// region utility functions
var removeDeprecatedIndexes=/*#__PURE__*/function(){var _removeDeprecatedIndexes=_asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee6(connection,models,modelConfiguration){var genericIndexes,_iterator3,_step3,index,exists,_i,_Object$entries,_Object$entries$_i,modelName,model,_i2,_determineGenericInde,name,_t4;return _regenerator().w(function(_context6){while(1)switch(_context6.p=_context6.n){case 0:_context6.n=1;return connection.getIndexes();case 1:genericIndexes=_context6.v.indexes.filter(function(index){return index.name.endsWith("-GenericIndex")});_iterator3=_createForOfIteratorHelper(genericIndexes);_context6.p=2;_iterator3.s();case 3:if((_step3=_iterator3.n()).done){_context6.n=8;break}index=_step3.value;exists=false;_i=0,_Object$entries=Object.entries(models);case 4:if(!(_i<_Object$entries.length)){_context6.n=6;break}_Object$entries$_i=_slicedToArray(_Object$entries[_i],2),modelName=_Object$entries$_i[0],model=_Object$entries$_i[1];if(!index.name.startsWith("".concat(modelName,"-"))){_context6.n=5;break}for(_i2=0,_determineGenericInde=determineGenericIndexablePropertyNames(modelConfiguration,model);_i2<_determineGenericInde.length;_i2++){name=_determineGenericInde[_i2];if(["".concat(modelName,"-").concat(name,"-GenericIndex"),"".concat(modelName,"-GenericIndex")].includes(index.name))exists=true}return _context6.a(3,6);case 5:_i++;_context6.n=4;break;case 6:if(exists){_context6.n=7;break}_context6.n=7;return connection.deleteIndex(index);case 7:_context6.n=3;break;case 8:_context6.n=10;break;case 9:_context6.p=9;_t4=_context6.v;_iterator3.e(_t4);case 10:_context6.p=10;_iterator3.f();return _context6.f(10);case 11:return _context6.a(2)}},_callee6,null,[[2,9,10,11]])}));function removeDeprecatedIndexes(_x12,_x13,_x14){return _removeDeprecatedIndexes.apply(this,arguments)}return removeDeprecatedIndexes}();/**
 * Converts internal declarative database connector configuration object
 * into a database compatible one.
 * @param configuration - Connector configuration object.
 * @param abortControllerStack - Stack to put abort signals to. They will be
 * shifted and used for fetch calls.
 * @returns Database compatible configuration object.
 */var getConnectorOptions=function getConnectorOptions(configuration,abortControllerStack){/*
        NOTE: We convert given fetch options into a fetch function wrapper
        which is than accepted by pouchdb's api.
    */var getOptions=function getOptions(options){var _abortControllerStack;if(options===void 0){options={}}options=(0,external_clientnode_.extend)(true,(0,external_clientnode_.copy)(configuration.fetch),options);if(Array.isArray(abortControllerStack)&&abortControllerStack.length>0)options.signal=(_abortControllerStack=abortControllerStack.pop())===null||_abortControllerStack===void 0?void 0:_abortControllerStack.controller.signal;return options};var KNOWN_ERRORS=new Map([[408,"Request Timeout"],[425,"Too Early"],[429,"Too Many Requests"],[502,"Bad Gateway"],[503,"Service Unavailable"],[504,"Gateway Timeout"]]);return _objectSpread(_objectSpread({},configuration),{},{fetch:function fetch(url,options){var _configuration$fetchI=configuration.fetchInterceptor,numberOfRetries=_configuration$fetchI.numberOfRetries,retryIntervalInSeconds=_configuration$fetchI.retryIntervalInSeconds,exponentialBackoff=_configuration$fetchI.exponentialBackoff,maximumRetryIntervalInSeconds=_configuration$fetchI.maximumRetryIntervalInSeconds;// Provides a retry mechanism with configurable delay mechanism.
var $result=__WEBPACK_EXTERNAL_MODULE_rxjs_fetch_acb1bba5_fromFetch__(url,getOptions(options)).pipe(__WEBPACK_EXTERNAL_MODULE_rxjs_map__(function(response){if(KNOWN_ERRORS.has(response.status))// eslint-disable-next-line no-throw-literal
throw response;return response}),__WEBPACK_EXTERNAL_MODULE_rxjs_retry__({count:numberOfRetries,delay:function delay(error,retryCount){// Client side error will just be forwarded
if(typeof error.status!=="number")throw error;var httpError=error;if(httpError.headers.has("retry-after")){var retryValue=httpError.headers.get("retry-after");if(typeof retryValue==="string"){var intervalInSeconds=parseInt(retryValue);if(String(intervalInSeconds)===retryValue){log.info("Retry in ".concat(retryValue," seconds"),"according to given retry value.");// We interpret value as seconds.
return __WEBPACK_EXTERNAL_MODULE_rxjs_timer__(intervalInSeconds*1000)}var futureRetryMoment=new Date(retryValue);if(!isNaN(futureRetryMoment.getTime())){var now=new Date;if(now<futureRetryMoment){if(maximumRetryIntervalInSeconds<(futureRetryMoment.getTime()-now.getTime())/1000){log.info("Retry at",futureRetryMoment.toUTCString(),"according to given retry","value.");return __WEBPACK_EXTERNAL_MODULE_rxjs_timer__(futureRetryMoment)}log.warn("The recommended retry attempt is",futureRetryMoment.toUTCString(),"further in the future than the","configured maximum wait time of",maximumRetryIntervalInSeconds,"seconds.")}else log.warn("Given retry time recommendation","from server is in the past and","has to be ignored therefore.")}}}var delayInSeconds=exponentialBackoff?Math.pow(2,retryCount-1)*retryIntervalInSeconds:retryIntervalInSeconds;return __WEBPACK_EXTERNAL_MODULE_rxjs_timer__(Math.min(delayInSeconds,maximumRetryIntervalInSeconds)*1000)}}));return __WEBPACK_EXTERNAL_MODULE_rxjs_lastValueFrom__($result)}})};/**
 * Determines a representation for given plain object.
 * @param object - Object to represent.
 * @param maximumRepresentationTryLength - Maximum representation string to
 * process.
 * @param maximumRepresentationLength - Maximum length of returned
 * representation.
 * @returns Representation string.
 */var mayStripRepresentation=function mayStripRepresentation(object,maximumRepresentationTryLength,maximumRepresentationLength){var representation=(0,external_clientnode_.represent)(object);if(representation.length<=maximumRepresentationTryLength){if(representation.length>maximumRepresentationLength)return representation.substring(0,maximumRepresentationLength-"...".length)+"..."}else return"DOCUMENT IS TOO BIG TO REPRESENT";return representation};/**
 * Updates/creates a design document in database with a validation function
 * set to given code.
 * @param databaseConnection - Database connection to use for document
 * updates.
 * @param documentName - Design document name.
 * @param documentData - Design document data.
 * @param description - Used to produce semantic logging messages.
 * @param doLogging - Enables logging.
 * @param idName - Property name for ids.
 * @param revisionName - Property name for revisions.
 * @param designDocumentNamePrefix - Document name prefix indicating deign
 * documents.
 * @returns Promise which will be resolved after given document has updated
 * successfully.
 */var ensureValidationDocumentPresence=/*#__PURE__*/function(){var _ensureValidationDocumentPresence=_asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee7(databaseConnection,documentName,documentData,description,doLogging,idName,revisionName,designDocumentNamePrefix){var newDocument,oldDocument,_t5,_t6;return _regenerator().w(function(_context7){while(1)switch(_context7.p=_context7.n){case 0:if(doLogging===void 0){doLogging=true}if(idName===void 0){idName="_id"}if(revisionName===void 0){revisionName="_rev"}if(designDocumentNamePrefix===void 0){designDocumentNamePrefix="_design/"}newDocument=_objectSpread(_defineProperty(_defineProperty(_defineProperty({},idName,"".concat(designDocumentNamePrefix).concat(documentName)),"language","javascript"),"version",package_0/* version */.rE),documentData);_context7.p=1;_context7.n=2;return databaseConnection.get("".concat(designDocumentNamePrefix).concat(documentName));case 2:oldDocument=_context7.v;newDocument[revisionName]=oldDocument[revisionName];_context7.n=3;return databaseConnection.put(newDocument);case 3:if(doLogging)log.info("".concat(description," updated."));_context7.n=8;break;case 4:_context7.p=4;_t5=_context7.v;if(doLogging)if(_t5.error==="not_found"||_t5.name==="not_found"||_t5.message==="missing"||_t5.reason==="missing")log.info("".concat(description," not available. Create new one."));else log.info("".concat(description," couldn't be updated:"),"\"".concat((0,external_clientnode_.represent)(_t5),"\" create new one."));_context7.p=5;_context7.n=6;return databaseConnection.put(newDocument);case 6:if(doLogging)log.info("".concat(description," installed/updated."));_context7.n=8;break;case 7:_context7.p=7;_t6=_context7.v;throw new Error("".concat(description," couldn't be installed/updated: ")+"\"".concat((0,external_clientnode_.represent)(_t6),"\"."),{cause:_t6});case 8:return _context7.a(2)}},_callee7,null,[[5,7],[1,4]])}));function ensureValidationDocumentPresence(_x15,_x16,_x17,_x18,_x19,_x20,_x21,_x22){return _ensureValidationDocumentPresence.apply(this,arguments)}return ensureValidationDocumentPresence}();/**
 * Initializes a database connection instance.
 * @param services - An object with stored service instances.
 * @param configuration - Mutable by plugins extended configuration object.
 * @param checkForDatabaseReachability - Indicates whether to check for
 * reachability of newly created database.
 * @returns Given and extended object of services.
 */var initializeConnection=/*#__PURE__*/function(){var _initializeConnection=_asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee8(services,configuration,checkForDatabaseReachability){var couchdb,config,url,_t7;return _regenerator().w(function(_context8){while(1)switch(_context8.p=_context8.n){case 0:if(checkForDatabaseReachability===void 0){checkForDatabaseReachability=true}couchdb=services.couchdb;config=configuration.couchdb;url=getEffectiveURL(config);/*
        NOTE: We have to connect remotely for a memory based database to avoid
        having multiple ones created per connector instance.
    */if(services.couchdb.server.expressPouchDBInstance){// @ts-expect-error "pouchdb-validation" does not have a typings yet.
couchdb.connection=new couchdb.connector(config.databaseName,couchdb.server.runner.configuration);couchdb.connection.installValidationMethods()}else// @ts-expect-error "pouchdb-validation" does not have a typings yet.
couchdb.connection=new couchdb.connector(url,getConnectorOptions(config.connector));couchdb.connection.installCouchDBWebNodePlugin("backend");couchdb.connection.setMaxListeners(Infinity);// region ensure database presence
if(!checkForDatabaseReachability){_context8.n=4;break}_context8.p=1;_context8.n=2;return couchdb.connection.allDocs({limit:1});case 2:_context8.n=4;break;case 3:_context8.p=3;_t7=_context8.v;throw new Error("Database has not been installed yet: ".concat((0,external_clientnode_.represent)(_t7)),{cause:_t7});case 4:return _context8.a(2,services)}},_callee8,null,[[1,3]])}));function initializeConnection(_x23,_x24,_x25){return _initializeConnection.apply(this,arguments)}return initializeConnection}();/**
 * Determines the effective database URL to connect to based on given
 * configuration.
 * @param configuration - Couchdb configuration object.
 * @param withDatabase - Indicates whether the URL should contain the database
 * name or not.
 * @param withCredentials - Indicates whether the URL should contain the
 * credentials or not.
 * @returns The effective URL.
 */var getEffectiveURL=function getEffectiveURL(configuration,withDatabase,withCredentials){if(withDatabase===void 0){withDatabase=true}if(withCredentials===void 0){withCredentials=false}var urlTemplate=/^https?:\/\//.test(configuration.url)?configuration.url:"http://{1}".concat(configuration.runner.host,":")+String(configuration.runner.port);return (0,external_clientnode_.format)(urlTemplate,withCredentials?"".concat(configuration.admin.name,":")+"".concat(configuration.admin.password,"@"):"")+(withDatabase?"/".concat(configuration.databaseName):"")};/**
 * Waits for given promise to be resolved or given timeout has been exceeded.
 * @param promise - Promise to wait for.
 * @param timeoutInSeconds - Timeout in seconds.
 * @param description - Used to produce semantic logging messages.
 * @returns A promise which will be resolved after given promise is resolved or
 * given timeout has been exceeded.
 */var waitWithTimeout=function waitWithTimeout(promise,timeoutInSeconds,description){var timeoutExceeded=true;return Promise.race([promise.then(function(){timeoutExceeded=false}),(0,external_clientnode_.timeout)(timeoutInSeconds*1000).then(function(){if(timeoutExceeded)log.warn("Timeout of","".concat(String(timeoutInSeconds),"."),"seconds reached while waiting for ".concat(description,"."))})])};// endregion
// region model
/**
 * Determines a mapping of all models to roles who are allowed to edit
 * corresponding model instances.
 * @param modelConfiguration - Model specification object.
 * @returns The mapping object.
 */var determineModelRolesMapping=function determineModelRolesMapping(modelConfiguration){var _modelConfiguration$p=modelConfiguration.property.name.special,rolePropertyName=_modelConfiguration$p.role,attachmentsPropertyName=_modelConfiguration$p.attachment;var modelRolesMapping={};var models=applyModelsInheritance(modelConfiguration);for(var _i3=0,_Object$entries2=Object.entries(models);_i3<_Object$entries2.length;_i3++){var _Object$entries2$_i=_slicedToArray(_Object$entries2[_i3],2),modelName=_Object$entries2$_i[0],model=_Object$entries2$_i[1];if(model[rolePropertyName]){modelRolesMapping[modelName]=_objectSpread({properties:{}},normalizeRoles(model[rolePropertyName]));for(var _i4=0,_Object$entries3=Object.entries(model);_i4<_Object$entries3.length;_i4++){var _Object$entries3$_i=_slicedToArray(_Object$entries3[_i4],2),name=_Object$entries3$_i[0],property=_Object$entries3$_i[1];if((0,external_clientnode_.isObject)(property))if(name===attachmentsPropertyName){modelRolesMapping[modelName].attachments={};for(var _i5=0,_Object$entries4=Object.entries(property);_i5<_Object$entries4.length;_i5++){var _Object$entries4$_i=_slicedToArray(_Object$entries4[_i5],2),fileDescription=_Object$entries4$_i[0],fileDefinition=_Object$entries4$_i[1];if(fileDefinition.roles)modelRolesMapping[modelName].attachments[fileDescription]=normalizeRoles(fileDefinition.roles)}}else if(property.roles)modelRolesMapping[modelName].properties[name]=normalizeRoles(property.roles)}}}return modelRolesMapping};/**
 * Determines whether given value of a model is a property specification.
 * @param value - Value to analyze.
 * @returns Boolean indicating the case.
 */var isPropertyDefinition=function isPropertyDefinition(value){return (0,external_clientnode_.isObject)(value)};/**
 * Determines all property names which are indexable in a generic manner.
 * @param modelConfiguration - Model specification object.
 * @param model - Model to determine property names from.
 * @returns The mapping object.
 */var determineGenericIndexablePropertyNames=function determineGenericIndexablePropertyNames(modelConfiguration,model){var specialNames=modelConfiguration.property.name.special;return Object.keys(model).filter(function(name){var specification=model[name];return isPropertyDefinition(specification)&&Object.prototype.hasOwnProperty.call(specification,"index")&&specification.index||isPropertyDefinition(specification)&&!(Object.prototype.hasOwnProperty.call(specification,"index")&&!specification.index||modelConfiguration.property.name.reserved.concat(specialNames.additional,specialNames.role,specialNames.attachment,specialNames.conflict,specialNames.constraint.execution,specialNames.constraint.expression,specialNames.deleted,specialNames.deletedConflict,specialNames.extend,specialNames.maximumAggregatedSize,specialNames.minimumAggregatedSize,specialNames.oldType,specialNames.id,specialNames.revision,specialNames.revisions,specialNames.revisionsInformation,specialNames.type,specialNames.updateStrategy).includes(name)||specification.type&&(typeof specification.type==="string"&&specification.type.endsWith("[]")||Array.isArray(specification.type)&&specification.type.length&&Array.isArray(specification.type[0])||Object.prototype.hasOwnProperty.call(modelConfiguration.entities,specification.type)))}).concat([specialNames.id,specialNames.revision]).sort()};/**
 * Extend given model with all specified one.
 * @param model - Model to extend.
 * @param modelConfiguration - Model specification object.
 * @param _name - Model name to extend. Only needed for debugging purposes.
 * @returns Given model in extended version.
 */var _applyModelInheritance=function applyModelInheritance(model,modelConfiguration,_name){if(_name===void 0){_name="in-place"}var models=modelConfiguration.entities;var extendPropertyName=modelConfiguration.property.name.special.extend;if(Object.prototype.hasOwnProperty.call(models,"_base"))if(Object.prototype.hasOwnProperty.call(model,extendPropertyName)&&model[extendPropertyName]&&![].concat(model[extendPropertyName]).includes("_base"))model[extendPropertyName]=["_base"].concat(model[extendPropertyName]);else model[extendPropertyName]="_base";if(Object.prototype.hasOwnProperty.call(model,extendPropertyName)){var originallyDeclaredExtensions=[].concat(model[extendPropertyName]);var _iterator4=_createForOfIteratorHelper(originallyDeclaredExtensions),_step4;try{for(_iterator4.s();!(_step4=_iterator4.n()).done;){var modelNameToExtend=_step4.value;if(modelNameToExtend!=="_base")_applyModelInheritance(models[modelNameToExtend],modelConfiguration,modelNameToExtend);/*
                NOTE: We need to merge into model to change the given object
                in-place. Furthermore, we have to copy the initial model before
                merging it finally to avoid having the inherited overwrites in
                the final model object as well.
             */(0,external_clientnode_.extend)(true,model,models[modelNameToExtend],(0,external_clientnode_.copy)(model));model[extendPropertyName]=originallyDeclaredExtensions}}catch(err){_iterator4.e(err)}finally{_iterator4.f()}delete model[extendPropertyName]}applyDefaultPropertyConfigurations(model,modelConfiguration);return model};/**
 * Apply default property definitions to given model.
 * @param model - Model to extends its properties.
 * @param modelConfiguration - Model configuration to take into account.
 * @returns Extended model.
 */var applyDefaultPropertyConfigurations=function applyDefaultPropertyConfigurations(model,modelConfiguration){var specialNames=modelConfiguration.property.name.special;for(var _i6=0,_Object$entries5=Object.entries(model);_i6<_Object$entries5.length;_i6++){var _Object$entries5$_i=_slicedToArray(_Object$entries5[_i6],2),name=_Object$entries5$_i[0],propertyDefinition=_Object$entries5$_i[1];if(name===specialNames.attachment){var fileDefinition=propertyDefinition;for(var _i7=0,_Object$entries6=Object.entries(fileDefinition);_i7<_Object$entries6.length;_i7++){var _Object$entries6$_i=_slicedToArray(_Object$entries6[_i7],2),type=_Object$entries6$_i[0],value=_Object$entries6$_i[1];fileDefinition[type]=(0,external_clientnode_.extend)(true,(0,external_clientnode_.copy)(modelConfiguration.property.defaultDefinition),value)}}else if(![specialNames.role,specialNames.constraint.execution,specialNames.constraint.expression,specialNames.extend,specialNames.maximumAggregatedSize,specialNames.minimumAggregatedSize,specialNames.oldType].includes(name)){var property=(0,external_clientnode_.extend)(true,(0,external_clientnode_.copy)(modelConfiguration.property.defaultDefinition),propertyDefinition);model[name]=property;var types=[].concat(property.type);var _iterator5=_createForOfIteratorHelper(types),_step5;try{for(_iterator5.s();!(_step5=_iterator5.n()).done;){var _type2=_step5.value;if(!Array.isArray(_type2)&&_typeof(_type2)==="object")property.type=_applyModelInheritance(_type2,modelConfiguration)}}catch(err){_iterator5.e(err)}finally{_iterator5.f()}}}return model};/**
 * Extend default specification with specific one.
 * @param modelConfiguration - Model specification object.
 * @returns Models with extended specific specifications.
 */var applyModelsInheritance=function applyModelsInheritance(modelConfiguration){var models=modelConfiguration.entities;var typePattern=modelConfiguration.property.name.typePattern;for(var _i8=0,_Object$keys=Object.keys(models);_i8<_Object$keys.length;_i8++){var modelName=_Object$keys[_i8];if(!(new RegExp(typePattern.public).test(modelName)||new RegExp(typePattern.private).test(modelName)))throw new Error("Model names have to match "+"\"".concat(typePattern.public,"\" or \"").concat(typePattern.private,"\" for ")+"xprivate one (given name: \"".concat(modelName,"\")."));if(modelName!=="_base")_applyModelInheritance(models[modelName],modelConfiguration,modelName)}return models};/**
 * Convert given roles to its normalized representation.
 * @param roles - Unstructured role's description.
 * @returns Normalized roles representation.
 */var normalizeRoles=function normalizeRoles(roles){if(Array.isArray(roles))return{read:roles,write:roles};if(_typeof(roles)==="object"){var result={read:[],write:[]};for(var _i9=0,_Object$keys2=Object.keys(result);_i9<_Object$keys2.length;_i9++){var type=_Object$keys2[_i9];if(Object.prototype.hasOwnProperty.call(roles,type)){var operationRoles=roles[type];if(Array.isArray(operationRoles))result[type]=operationRoles;else if(typeof operationRoles==="string")result[type]=[operationRoles]}}return result}return{read:[roles],write:[roles]}};// endregion
export { TOGGLE_LATEST_REVISION_DETERMINING, applyDefaultPropertyConfigurations, _applyModelInheritance as applyModelInheritance, applyModelsInheritance, determineGenericIndexablePropertyNames, determineModelRolesMapping, ensureValidationDocumentPresence, getConnectorOptions, getEffectiveURL, getPouchDBPlugin, initializeConnection, isPropertyDefinition, log, mayStripRepresentation, normalizeRoles, removeDeprecatedIndexes, waitWithTimeout };
